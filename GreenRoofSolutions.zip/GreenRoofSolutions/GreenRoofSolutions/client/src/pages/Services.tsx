import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  Leaf,
  Wrench,
  Sprout,
  Check,
  BadgeCheck,
  Settings,
  Shield,
} from "lucide-react";

const services = [
  {
    icon: <Leaf className="h-8 w-8" />,
    title: "Extensive Green Roofs",
    description:
      "Lightweight, low-maintenance systems perfect for large commercial buildings.",
    features: [
      "Drought-resistant plants",
      "Minimal maintenance required",
      "Ideal for retrofitting",
      "Enhanced building efficiency",
    ],
  },
  {
    icon: <Sprout className="h-8 w-8" />,
    title: "Intensive Green Roofs",
    description:
      "Deep-soil systems supporting diverse plants and creating garden spaces.",
    features: [
      "Wide plant variety",
      "Creates usable space",
      "Enhanced biodiversity",
      "Strong aesthetic appeal",
    ],
  },
  {
    icon: <Wrench className="h-8 w-8" />,
    title: "Maintenance Services",
    description:
      "Regular maintenance to ensure your green roof thrives year-round.",
    features: [
      "Seasonal inspections",
      "Plant health monitoring",
      "Irrigation management",
      "System optimization",
    ],
  },
];

const packages = [
  {
    title: "Basic",
    price: "$15",
    unit: "per sq ft",
    description: "Essential green roof solution",
    features: [
      "Basic plant selection",
      "Standard drainage system",
      "2-year warranty",
      "Basic maintenance guide",
    ],
  },
  {
    title: "Professional",
    price: "$25",
    unit: "per sq ft",
    description: "Enhanced green roof system",
    features: [
      "Extended plant variety",
      "Advanced drainage system",
      "5-year warranty",
      "Quarterly maintenance",
      "Smart irrigation system",
    ],
    highlighted: true,
  },
  {
    title: "Enterprise",
    price: "Custom",
    unit: "quote",
    description: "Complete custom solution",
    features: [
      "Custom design & planning",
      "Premium plant selection",
      "10-year warranty",
      "Monthly maintenance",
      "Advanced monitoring",
      "24/7 support",
    ],
  },
];

export default function Services() {
  return (
    <div className="min-h-screen">
      <motion.section
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="py-16 container"
      >
        <div className="max-w-3xl mx-auto text-center mb-16 px-6">
          <h1 className="text-4xl font-bold mb-6">Our Services</h1>
          <p className="text-lg text-muted-foreground">
            Comprehensive green roof solutions tailored to your needs
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="h-full">
                <CardContent className="pt-6">
                  <div className="text-primary mb-4">{service.icon}</div>
                  <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                  <p className="text-muted-foreground mb-4">
                    {service.description}
                  </p>
                  <ul className="space-y-2">
                    {service.features.map((feature) => (
                      <li key={feature} className="flex items-center space-x-2">
                        <Check className="h-4 w-4 text-primary" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="py-16">
          <h2 className="text-3xl font-bold text-center mb-12">Pricing Plans</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {packages.map((pkg, index) => (
              <motion.div
                key={pkg.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card
                  className={`h-full ${
                    pkg.highlighted
                      ? "border-primary shadow-lg"
                      : "border-border"
                  }`}
                >
                  <CardHeader>
                    <CardTitle className="text-2xl">{pkg.title}</CardTitle>
                    <div className="mt-4">
                      <span className="text-4xl font-bold">{pkg.price}</span>
                      <span className="text-muted-foreground">/{pkg.unit}</span>
                    </div>
                    <p className="text-muted-foreground mt-2">
                      {pkg.description}
                    </p>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-4">
                      {pkg.features.map((feature) => (
                        <li key={feature} className="flex items-center space-x-2">
                          <BadgeCheck className="h-5 w-5 text-primary" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Link href="/contact">
                      <Button
                        className={`w-full mt-6 ${
                          pkg.highlighted ? "bg-primary" : ""
                        }`}
                      >
                        Get Started
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="py-16 bg-muted/50 rounded-lg"
        >
          <div className="container text-center">
            <h2 className="text-3xl font-bold mb-8">Why Choose Us?</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <Settings className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Expert Installation</h3>
                <p className="text-muted-foreground">
                  Professional team with years of experience
                </p>
              </div>
              <div>
                <Shield className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Quality Guarantee</h3>
                <p className="text-muted-foreground">
                  Premium materials and workmanship
                </p>
              </div>
              <div>
                <BadgeCheck className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Certified Team</h3>
                <p className="text-muted-foreground">
                  Licensed and insured professionals
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.section>
    </div>
  );
}
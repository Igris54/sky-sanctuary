import { motion } from "framer-motion";
import QuoteForm from "@/components/sections/QuoteForm";
import { Card, CardContent } from "@/components/ui/card";
import {
  Mail,
  Phone,
  MapPin,
  Clock,
  MessageSquare,
} from "lucide-react";

const contactInfo = [
  {
    icon: <Phone className="h-6 w-6" />,
    title: "Phone",
    content: "(555) 123-4567",
    link: "tel:+15551234567",
  },
  {
    icon: <Mail className="h-6 w-6" />,
    title: "Email",
    content: "info@skysanctuary.com",
    link: "mailto:info@skysanctuary.com",
  },
  {
    icon: <MapPin className="h-6 w-6" />,
    title: "Address",
    content: "123 Green Street, Eco City, EC 12345",
    link: "https://maps.google.com",
  },
  {
    icon: <Clock className="h-6 w-6" />,
    title: "Hours",
    content: "Mon-Fri: 9AM-6PM",
  },
];

export default function Contact() {
  return (
    <div className="min-h-screen">
      <motion.section
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="py-16 container"
      >
        <div className="max-w-3xl mx-auto text-center mb-16 px-6">
          <h1 className="text-4xl font-bold mb-6">Contact Us</h1>
          <p className="text-lg text-muted-foreground">
            Get in touch with our team to discuss your green roof project
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-4">Get a Quote</h2>
              <p className="text-muted-foreground">
                Fill out the form below and we'll get back to you within 24 hours
                with a custom quote for your project.
              </p>
            </div>
            <QuoteForm />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-4">Contact Information</h2>
              <p className="text-muted-foreground">
                Have questions? Reach out to us through any of these channels:
              </p>
            </div>

            <div className="grid gap-6">
              {contactInfo.map((info) => (
                <Card key={info.title}>
                  <CardContent className="flex items-center space-x-4 p-6">
                    <div className="text-primary">{info.icon}</div>
                    <div>
                      <h3 className="font-semibold">{info.title}</h3>
                      {info.link ? (
                        <a
                          href={info.link}
                          className="text-muted-foreground hover:text-primary"
                        >
                          {info.content}
                        </a>
                      ) : (
                        <p className="text-muted-foreground">{info.content}</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="mt-8">
              <CardContent className="p-6">
                <div className="flex items-center space-x-2 mb-4">
                  <MessageSquare className="h-6 w-6 text-primary" />
                  <h3 className="font-semibold">Live Chat</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  Need immediate assistance? Chat with our team now.
                </p>
                <button className="w-full bg-primary text-primary-foreground py-2 rounded-md hover:bg-primary/90 transition-colors">
                  Start Chat
                </button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </motion.section>
    </div>
  );
}
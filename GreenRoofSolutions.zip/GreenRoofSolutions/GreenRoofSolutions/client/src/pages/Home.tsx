import { motion } from "framer-motion";
import Hero from "@/components/sections/Hero";
import Benefits from "@/components/sections/Benefits";
import Testimonials from "@/components/sections/Testimonials";

export default function Home() {
  return (
    <div>
      <Hero />
      <Benefits />
      
      <motion.section
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="py-16 container"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-4">
              The Future of Urban Spaces
            </h2>
            <p className="text-lg text-muted-foreground mb-6">
              Green roofs are more than just a trend – they're a crucial step
              towards sustainable urban development. Our solutions help buildings
              reduce their environmental impact while creating beautiful, functional
              spaces.
            </p>
            <ul className="space-y-4">
              {[
                "Reduces urban heat island effect",
                "Improves air quality",
                "Creates wildlife habitats",
                "Increases property value",
              ].map((item, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center space-x-2"
                >
                  <svg
                    className="h-5 w-5 text-primary"
                    fill="none"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path d="M5 13l4 4L19 7" />
                  </svg>
                  <span>{item}</span>
                </motion.li>
              ))}
            </ul>
          </div>
          <div className="relative h-[400px] rounded-lg overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1598033204229-c8ab8c07c70c?auto=format&fit=crop&q=80"
              alt="Green roof installation"
              className="absolute inset-0 w-full h-full object-cover"
            />
          </div>
        </div>
      </motion.section>
      
      <Testimonials />
    </div>
  );
}

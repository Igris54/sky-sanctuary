import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Leaf, Users, Target, Award } from "lucide-react";

const values = [
  {
    icon: <Leaf className="h-8 w-8" />,
    title: "Sustainability First",
    description: "We prioritize eco-friendly solutions and sustainable practices in every project."
  },
  {
    icon: <Users className="h-8 w-8" />,
    title: "Expert Team",
    description: "Our certified professionals bring years of experience in green roof installation."
  },
  {
    icon: <Target className="h-8 w-8" />,
    title: "Innovation",
    description: "We stay at the forefront of green technology and installation techniques."
  },
  {
    icon: <Award className="h-8 w-8" />,
    title: "Quality Assurance",
    description: "Every project meets the highest standards of quality and safety."
  }
];

export default function About() {
  return (
    <div className="min-h-screen">
      <motion.section
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="py-16 container"
      >
        <div className="max-w-3xl mx-auto text-center mb-16 px-6">
          <h1 className="text-4xl font-bold mb-6">About SkySanctuary</h1>
          <p className="text-lg text-muted-foreground">
            Leading the way in sustainable urban development through innovative
            green roof solutions.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <h2 className="text-3xl font-bold mb-4">Our Mission</h2>
            <p className="text-lg text-muted-foreground mb-6">
              At SkySanctuary, we're committed to transforming urban spaces into
              thriving ecosystems. Our mission is to combat climate change and
              enhance urban living through innovative green roof solutions.
            </p>
            <p className="text-lg text-muted-foreground">
              We believe that every roof has the potential to contribute to a
              healthier, more sustainable future. Through our expertise and
              dedication, we're making cities greener, one roof at a time.
            </p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="relative h-[400px] rounded-lg overflow-hidden"
          >
            <img
              src="https://images.unsplash.com/photo-1623241236297-30c724728aeb?auto=format&fit=crop&q=80"
              alt="Green roof installation team"
              className="absolute inset-0 w-full h-full object-cover"
            />
          </motion.div>
        </div>

        <div className="py-16 bg-muted/50 rounded-lg">
          <div className="container">
            <h2 className="text-3xl font-bold text-center mb-12">Our Values</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {values.map((value, index) => (
                <motion.div
                  key={value.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full">
                    <CardContent className="pt-6">
                      <div className="text-primary mb-4">{value.icon}</div>
                      <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                      <p className="text-muted-foreground">{value.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="py-16 text-center"
        >
          <h2 className="text-3xl font-bold mb-6">Our Impact</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-4xl font-bold text-primary mb-2">100+</h3>
              <p className="text-lg text-muted-foreground">Projects Completed</p>
            </div>
            <div>
              <h3 className="text-4xl font-bold text-primary mb-2">50,000+</h3>
              <p className="text-lg text-muted-foreground">Square Feet Greened</p>
            </div>
            <div>
              <h3 className="text-4xl font-bold text-primary mb-2">500+</h3>
              <p className="text-lg text-muted-foreground">Happy Clients</p>
            </div>
          </div>
        </motion.div>
      </motion.section>
    </div>
  );
}
import { motion } from "framer-motion";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

const projects = [
  {
    title: "EcoTower Green Roof",
    description: "Commercial building transformation with extensive green roof system",
    image: "https://images.unsplash.com/photo-1621847468516-1ed5d0df56fe?auto=format&fit=crop&q=80",
    details: {
      size: "15,000 sq ft",
      type: "Extensive Green Roof",
      location: "Downtown Metro",
      completion: "2023",
      features: [
        "Native plant species",
        "Smart irrigation system",
        "Solar integration",
        "Rainwater harvesting",
      ],
    },
  },
  {
    title: "Skyline Gardens",
    description: "Residential complex with intensive garden roof",
    image: "https://images.unsplash.com/photo-1599769568315-734e44416cc9?auto=format&fit=crop&q=80",
    details: {
      size: "8,000 sq ft",
      type: "Intensive Green Roof",
      location: "Suburban Heights",
      completion: "2023",
      features: [
        "Community garden space",
        "Walking paths",
        "Seating areas",
        "Diverse plant selection",
      ],
    },
  },
  {
    title: "Tech Hub Eco-Roof",
    description: "Modern office building with sustainable rooftop solution",
    image: "https://images.unsplash.com/photo-1592483478498-30165187bd1c?auto=format&fit=crop&q=80",
    details: {
      size: "12,000 sq ft",
      type: "Hybrid System",
      location: "Innovation District",
      completion: "2022",
      features: [
        "Solar panel integration",
        "Drought-resistant plants",
        "Automated maintenance",
        "Educational space",
      ],
    },
  },
  {
    title: "Green Healthcare Center",
    description: "Hospital rooftop healing garden",
    image: "https://images.unsplash.com/photo-1590529478072-8c6b56a8dd2e?auto=format&fit=crop&q=80",
    details: {
      size: "10,000 sq ft",
      type: "Therapeutic Garden",
      location: "Medical Campus",
      completion: "2023",
      features: [
        "Meditation spaces",
        "Therapeutic plants",
        "Accessible design",
        "Year-round blooms",
      ],
    },
  },
  {
    title: "Urban Farm Project",
    description: "Sustainable rooftop agriculture initiative",
    image: "https://images.unsplash.com/photo-1591857177593-aec9bc535394?auto=format&fit=crop&q=80",
    details: {
      size: "20,000 sq ft",
      type: "Agricultural Roof",
      location: "City Center",
      completion: "2023",
      features: [
        "Vegetable gardens",
        "Greenhouse integration",
        "Composting system",
        "Educational programs",
      ],
    },
  },
  {
    title: "Eco-Hotel Sanctuary",
    description: "Luxury hotel rooftop garden and lounge",
    image: "https://images.unsplash.com/photo-1598033204229-c8ab8c07c70c?auto=format&fit=crop&q=80",
    details: {
      size: "6,000 sq ft",
      type: "Luxury Garden Roof",
      location: "Downtown",
      completion: "2022",
      features: [
        "Event space",
        "Water features",
        "Native landscaping",
        "Outdoor dining area",
      ],
    },
  },
];

export default function Portfolio() {
  return (
    <div className="min-h-screen">
      <motion.section
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="py-16 container"
      >
        <div className="max-w-3xl mx-auto text-center mb-16 px-6">
          <h1 className="text-4xl font-bold mb-6">Our Portfolio</h1>
          <p className="text-lg text-muted-foreground">
            Explore our completed green roof projects and see how we're
            transforming urban spaces.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Dialog>
                <DialogTrigger asChild>
                  <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                    <div className="aspect-video relative overflow-hidden">
                      <img
                        src={project.image}
                        alt={project.title}
                        className="absolute inset-0 w-full h-full object-cover"
                      />
                    </div>
                    <CardHeader>
                      <CardTitle>{project.title}</CardTitle>
                      <CardDescription>{project.description}</CardDescription>
                    </CardHeader>
                  </Card>
                </DialogTrigger>
                <DialogContent className="max-w-3xl">
                  <DialogHeader>
                    <DialogTitle>{project.title}</DialogTitle>
                    <DialogDescription>{project.description}</DialogDescription>
                  </DialogHeader>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="aspect-video relative rounded-lg overflow-hidden">
                      <img
                        src={project.image}
                        alt={project.title}
                        className="absolute inset-0 w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-semibold">Project Details</h4>
                          <p className="text-sm text-muted-foreground">
                            Size: {project.details.size}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Type: {project.details.type}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Location: {project.details.location}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Completed: {project.details.completion}
                          </p>
                        </div>
                        <div>
                          <h4 className="font-semibold">Key Features</h4>
                          <ul className="list-disc list-inside text-sm text-muted-foreground">
                            {project.details.features.map((feature) => (
                              <li key={feature}>{feature}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </motion.div>
          ))}
        </div>
      </motion.section>
    </div>
  );
}
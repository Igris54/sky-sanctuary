import { motion } from "framer-motion";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const testimonials = [
  {
    name: "Sarah Johnson",
    role: "Property Manager",
    image: "https://i.pravatar.cc/150?img=1",
    content:
      "The green roof installation by SkySanctuary has transformed our building. Not only does it look beautiful, but we've seen significant energy savings.",
  },
  {
    name: "Michael Chen",
    role: "Building Owner",
    image: "https://i.pravatar.cc/150?img=2",
    content:
      "Outstanding service from start to finish. The team was professional, and the result exceeded our expectations. Highly recommend!",
  },
  {
    name: "Emily Rodriguez",
    role: "Sustainability Director",
    image: "https://i.pravatar.cc/150?img=3",
    content:
      "SkySanctuary helped us achieve our sustainability goals while creating a beautiful space for our employees to enjoy.",
  },
];

export default function Testimonials() {
  return (
    <section className="py-16 bg-background">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">What Our Clients Say</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Hear from building owners and managers who have transformed their
            properties with our green roof solutions.
          </p>
        </motion.div>

        <Carousel className="w-full max-w-4xl mx-auto">
          <CarouselContent>
            {testimonials.map((testimonial, index) => (
              <CarouselItem key={index}>
                <Card className="mx-4">
                  <CardContent className="p-6 text-center">
                    <Avatar className="w-20 h-20 mx-auto mb-4">
                      <AvatarImage src={testimonial.image} alt={testimonial.name} />
                      <AvatarFallback>
                        {testimonial.name.split(" ").map((n) => n[0]).join("")}
                      </AvatarFallback>
                    </Avatar>
                    <p className="text-lg mb-4">{testimonial.content}</p>
                    <div>
                      <h4 className="font-semibold">{testimonial.name}</h4>
                      <p className="text-sm text-muted-foreground">
                        {testimonial.role}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious />
          <CarouselNext />
        </Carousel>
      </div>
    </section>
  );
}

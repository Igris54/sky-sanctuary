import { motion } from "framer-motion";
import { Leaf, Droplets, ThermometerSun, Battery } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const benefits = [
  {
    icon: <Leaf className="h-8 w-8" />,
    title: "Improved Air Quality",
    description:
      "Green roofs filter pollutants and CO2 from the air, contributing to better urban air quality.",
  },
  {
    icon: <Droplets className="h-8 w-8" />,
    title: "Water Management",
    description:
      "Reduces stormwater runoff by absorbing and filtering rainwater naturally.",
  },
  {
    icon: <ThermometerSun className="h-8 w-8" />,
    title: "Energy Efficiency",
    description:
      "Natural insulation reduces heating and cooling costs throughout the year.",
  },
  {
    icon: <Battery className="h-8 w-8" />,
    title: "Extended Roof Life",
    description:
      "Protects roofing materials from UV rays and extreme weather, doubling roof lifespan.",
  },
];

export default function Benefits() {
  return (
    <section className="py-16 bg-muted/50">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">Benefits of Green Roofs</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover how green roofs can transform your building while contributing
            to a more sustainable urban environment.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((benefit, index) => (
            <motion.div
              key={benefit.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full">
                <CardContent className="pt-6">
                  <div className="text-primary mb-4">{benefit.icon}</div>
                  <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
                  <p className="text-muted-foreground">{benefit.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

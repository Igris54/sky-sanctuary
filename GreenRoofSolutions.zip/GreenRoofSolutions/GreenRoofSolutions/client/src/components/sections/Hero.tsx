import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Hero() {
  return (
    <div className="relative min-h-[80vh] flex items-center">
      <div 
        className="absolute inset-0 bg-gradient-to-r from-background/90 to-background/50"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1591166803614-86ef43e4c35b?auto=format&fit=crop&q=80')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />
      
      <div className="container relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-2xl"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Transform Your Roof,{" "}
            <span className="text-primary">Transform Your City</span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground mb-8">
            Create sustainable, living spaces that benefit both your property and
            the environment with our expert green roof installations.
          </p>

          <div className="space-x-4">
            <Link href="/contact">
              <Button size="lg" className="bg-primary text-primary-foreground">
                Get a Free Consultation
              </Button>
            </Link>
            <Link href="/portfolio">
              <Button size="lg" variant="outline">
                View Our Projects
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
